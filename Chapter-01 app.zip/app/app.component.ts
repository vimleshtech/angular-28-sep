import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  //declaration of variable
  name:string='nitin';
  id:number=101
  gender:string='male'

  products = [
    {name:'dove',ismark:false},
    {name:'iphone',ismark:false},
    {name:'hp',ismark:false},
    {name:'other product',ismark:false}
  ]

  count=0
  dellAll(){
    this.products = this.products.filter(x => x.ismark==false);


  }
  getIndex(i){
    this.products[i].ismark = !this.products[i].ismark;
    console.log(this.products);

    this.count =this.products.filter(x=>x.ismark==true).length;


    console.log(this.count);

  }
  setName(event){

    this.name = event.target.value;

  }
  frm_sub(){
    //alert('test code');
    console.log('test code');
    this.products.push(this.name);
  }

  deleterow(){


  }

  setCheckbox(){
 
    
  }
}

//export default AppComponent;
