import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mytrip',
  templateUrl: './mytrip.component.html',
  styleUrls: ['./mytrip.component.css']
})
export class MytripComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
