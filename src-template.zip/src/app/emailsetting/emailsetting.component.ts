import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emailsetting',
  templateUrl: './emailsetting.component.html',
  styleUrls: ['./emailsetting.component.css']
})
export class EmailsettingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
