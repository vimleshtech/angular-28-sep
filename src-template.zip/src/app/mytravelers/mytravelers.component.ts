import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mytravelers',
  templateUrl: './mytravelers.component.html',
  styleUrls: ['./mytravelers.component.css']
})
export class MytravelersComponent implements OnInit {

  title="test title ";
  
  constructor() { }

  ngOnInit() {
  }

}
