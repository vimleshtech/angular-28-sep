import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mybillingdetails',
  templateUrl: './mybillingdetails.component.html',
  styleUrls: ['./mybillingdetails.component.css']
})
export class MybillingdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
