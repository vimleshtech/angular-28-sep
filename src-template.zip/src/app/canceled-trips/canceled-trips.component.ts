import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-canceled-trips',
  templateUrl: './canceled-trips.component.html',
  styleUrls: ['./canceled-trips.component.css']
})
export class CanceledTripsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
