
export class Sales{

    private oid:number;
    private pid:number;
    private cid:number;
    private qty:number;
    private price:number;
    

    constructor(){
    }


    newOrder(oid:number,pid:number,cid:number,qty:number,price:number){ //pprice?:number : is nuable 

        this.oid = oid;
        this.pid = pid;
        this.cid = cid;
        this.qty = qty;
        this.price = price;
    }
    
    getProduct(){
     
        return {oid:this.oid,pid:this.pid,cid:this.cid,qty:this.qty,price:this.price};

    }
}
