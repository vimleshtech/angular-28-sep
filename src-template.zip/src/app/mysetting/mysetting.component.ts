import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mysetting',
  templateUrl: './mysetting.component.html',
  styleUrls: ['./mysetting.component.css']
})
export class MysettingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
