import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myrewards',
  templateUrl: './myrewards.component.html',
  styleUrls: ['./myrewards.component.css']
})
export class MyrewardsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
