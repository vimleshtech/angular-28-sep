import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upcoming-trips',
  templateUrl: './upcoming-trips.component.html',
  styleUrls: ['./upcoming-trips.component.css']
})
export class UpcomingTripsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
