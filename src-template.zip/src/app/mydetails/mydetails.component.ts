import { Component, OnInit } from '@angular/core';
import { constructDependencies } from '@angular/core/src/di/reflective_provider';

@Component({
  selector: 'app-mydetails',
  templateUrl: './mydetails.component.html',
  styleUrls: ['./mydetails.component.css']
})
export class MydetailsComponent implements OnInit {

  //Attribuates
  msg
  ask_id
  app_name
  project_name
  upload_token

  global_group
  app_type
  scan_freq
  data_center
  segment
  cmdb_id
  app_prod_url
  description

  dev_plateform
  own_name
  own_email 
  to_recipt
  cc_recipt
  remarks

  apps=[]

  constructor() { 
    this.msg=''
    this.apps=[]
    this.apps.push({ask_id:"ASK ID",
      app_name:"App Name",
      project_name:"Project Name",
      upload_token:"Token",        
      global_group:"Global Group",
      app_type:"App Type",
      scan_freq:"Freq",
      data_center:"Data Center",
      segment:"Segment",
      cmdb_id:"",
      app_prod_url:"App URL",
      description:"Desc",
    
      dev_plateform:"Dev Plateform",
      own_name:"Owner Name",
      own_email :"",
      to_recipt:"",
      cc_recipt:"",
      remarks:""})

    localStorage.setItem("apps",JSON.stringify(this.apps));

    this.ask_id=''
    this.app_name=''
    this.project_name=''
    this.upload_token=''
  
    this.global_group=''
    this.app_type=''
    this.scan_freq=''
    this.data_center=''
    this.segment=''
    this.cmdb_id=''
    this.app_prod_url=''
    this.description=''
  
    this.dev_plateform=''
    this.own_name=''
    this.own_email =''
    this.to_recipt=''
    this.cc_recipt=''
    this.remarks=''

  }

  ngOnInit() {
  }

  set_ask_id(event){

    this.ask_id = event.target.value;
    console.log(this.ask_id);

  }
  set_app_name(event){
    this.app_name = event.target.value;
    console.log(this.app_name);
      }
      set_project_name(event){
        this.project_name = event.target.value;
        console.log(this.project_name);
      }
      set_upload_token(event){

        this.upload_token = event.target.value;
        console.log(this.upload_token);
      }

      set_global_group(event){
        this.global_group = event.target.value;
        console.log(this.global_group);
      }
      set_app_type(event){
        this.app_type = event.target.value;
        console.log(this.app_type);
      }
      set_scan_freq(event){
        this.scan_freq = event.target.value;
        console.log(this.scan_freq);
      }
      set_data_center(event){
        this.data_center = event.target.value;
        console.log(this.data_center);
      }
      set_segment(event){
        this.segment = event.target.value;
        console.log(this.segment);
      }
      set_cmdb_id(event){
        this.cmdb_id = event.target.value;
        console.log(this.cmdb_id);
      }
      set_app_prod_url(event){
        this.app_prod_url = event.target.value;
        console.log(this.app_prod_url);
      }
      set_description(event){
        this.description = event.target.value;
        console.log(this.description);
      }

      set_dev_plateform(event){
        this.dev_plateform = event.target.value;
        console.log(this.dev_plateform);
      }
      set_own_name(event){
        this.own_name = event.target.value;
        console.log(this.own_name);
      }
      set_own_email (event){
        this.own_email = event.target.value;
        console.log(this.own_email);
      }
      set_to_recipt(event){
        this.to_recipt = event.target.value;
        console.log(this.to_recipt);
      }
      set_cc_recipt(event){
        this.cc_recipt = event.target.value;
        console.log(this.cc_recipt);
      }
      set_remarks(event){
        this.remarks = event.target.value;
        console.log(this.remarks);
      }

      app_save(){

        if(this.ask_id.length<1)
        {
            alert('ASK ID cannot be empty!!');
            this.msg='';
        }
        else{

        
        this.apps.push({ask_id:this.ask_id,
          app_name:this.app_name,
          project_name:this.project_name,
          upload_token:this.upload_token,        
          global_group:this.global_group,
          app_type:this.app_type,
          scan_freq:this.scan_freq,
          data_center:this.data_center,
          segment:this.segment,
          cmdb_id:this.cmdb_id,
          app_prod_url:this.app_prod_url,
          description:this.description,
        
          dev_plateform:this.dev_plateform,
          own_name:this.own_email,
          own_email :this.own_email,
          to_recipt:this.to_recipt,
          cc_recipt:this.cc_recipt,
          remarks:this.remarks})

        console.log('saved...');
        console.log(this.apps);

        localStorage.setItem("apps",JSON.stringify(this.apps));

        alert('Application details is saved. Go to my application to view the list.');

        this.msg ='Application details is saved. Go to my application to view the list.';
        this.ask_id='';
        this.app_name='';
        this.project_name='';
        this.upload_token='';
      
        this.global_group='';
        this.app_type='';
        this.scan_freq='';
        this.data_center='';
        this.segment='';
        this.cmdb_id='';
        this.app_prod_url='';
        this.description='';
      
        this.dev_plateform='';
        this.own_name='';
        this.own_email ='';
        this.to_recipt='';
        this.cc_recipt='';
        this.remarks='';

        }

      }
}
