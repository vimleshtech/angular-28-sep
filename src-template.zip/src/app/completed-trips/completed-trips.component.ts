import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-completed-trips',
  templateUrl: './completed-trips.component.html',
  styleUrls: ['./completed-trips.component.css']
})
export class CompletedTripsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
