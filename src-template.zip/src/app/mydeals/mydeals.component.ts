import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mydeals',
  templateUrl: './mydeals.component.html',
  styleUrls: ['./mydeals.component.css']
})
export class MydealsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
