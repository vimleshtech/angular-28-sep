import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-travelpreference',
  templateUrl: './travelpreference.component.html',
  styleUrls: ['./travelpreference.component.css']
})
export class TravelpreferenceComponent implements OnInit {

  apps
  constructor() { 

    this.apps=[]
  }

  ngOnInit() {
  }

  load_recent_apps(){

    var retrievedData = localStorage.getItem("apps");JSON.parse(retrievedData);

    this.apps= JSON.parse(retrievedData);

    console.log(this.apps);
  }
}
