import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  name:string="Test User"
  id=110

  data= [{id:1,name:'nitin'},{id:11,name:'jatin'}]
  
  

  
}

//export default AppComponent;
