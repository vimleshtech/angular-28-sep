import { Component, OnInit,OnChanges, Input,SimpleChanges } from '@angular/core';
import { POINT_CONVERSION_COMPRESSED } from 'constants';

@Component({
  selector: 'app-item-detail',
  templateUrl: './item-detail.component.html',
  styleUrls: ['./item-detail.component.css']
})
export class ItemDetailComponent implements OnInit, OnChanges {

  @Input()
  data 
  
  constructor() { }

  ngOnInit() {
  }

  ngOnChanges(changes:SimpleChanges ) {
    
        console.log('in onChanges =  '+changes);
        
        if (typeof changes['data'] !== "undefined") {
          
                      // retrieve the quiz variable change info
                      var change = changes['data'];                      
                      console.log('data is ',change.previousValue);
                      console.log('data is ',change.currentValue);
                      
                      //SimpleChange {previousValue: undefined, currentValue: "f", firstChange: false}
          }

    
      }

}
